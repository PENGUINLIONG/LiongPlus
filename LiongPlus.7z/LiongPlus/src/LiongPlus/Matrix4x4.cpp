// File: Matrix4x4.cpp
// Author: Rendong Liang (Liong)
#include <immintrin.h>
#include <stdexcept>
#include "LiongPlus/Matrix4x4.hpp"

_L_NS_BEG

namespace details {
	template<typename TFloat>
	TFloat clamp(TFloat val, TFloat lower, TFloat upper)
	{
		return std::fmin(std::fmax(val, lower), upper);
	}
}

//
// Vector4
//

float _Vector4<float>::operator()(size_t pos) const
{
	switch (pos)
	{
		case 0: return X;
		case 1: return Y;
		case 2: return Z;
		case 3: return W;
		default: throw std::runtime_error("$pos exceeded boundary.");
	}
}
float& _Vector4<float>::operator()(size_t pos)
{
	switch (pos)
	{
		case 0: return X;
		case 1: return Y;
		case 2: return Z;
		case 3: return W;
		default: throw std::runtime_error("$pos exceeded boundary.");
	}
}

float _Vector4<float>::Dot(const _Vector4<float>& vector) const
{
	__m128 xy = _mm_mul_ps(*reinterpret_cast<const __m128*>(this), *reinterpret_cast<const __m128*>(&vector));
	__m128 temp = _mm_hadd_ps(xy, xy);
	__m128 hi64;
	hi64.m128_i32[0] = _mm_extract_ps(temp, 1);
	__m128 dotproduct = _mm_add_ss(*(__m128*)&temp, hi64);
	return dotproduct.m128_f32[0];
}
_Vector4<float> _Vector4<float>::Clamp(float lower, float upper) const
{
	using namespace details;
	return {
		clamp(X, lower, upper),
		clamp(Y, lower, upper),
		clamp(Z, lower, upper),
		clamp(W, lower, upper),
	};
}

double _Vector4<double>::operator()(size_t pos) const
{
	switch (pos)
	{
		case 0: return X;
		case 1: return Y;
		case 2: return Z;
		case 3: return W;
		default: throw std::runtime_error("$pos exceeded boundary.");
	}
}
double& _Vector4<double>::operator()(size_t pos)
{
	switch (pos)
	{
		case 0: return X;
		case 1: return Y;
		case 2: return Z;
		case 3: return W;
		default: throw std::runtime_error("$pos exceeded boundary.");
	}
}

double _Vector4<double>::Dot(const _Vector4<double>& vector) const
{
	__m256d xy = _mm256_mul_pd(*reinterpret_cast<const __m256d*>(this), *reinterpret_cast<const __m256d*>(&vector));
	__m256d temp = _mm256_hadd_pd(xy, xy);
	__m128d hi128 = _mm256_extractf128_pd(temp, 1);
	__m128d dotproduct = _mm_add_sd(*(__m128d*)&temp, hi128);
	return dotproduct.m128d_f64[0];
}
_Vector4<double> _Vector4<double>::Clamp(double lower, double upper) const
{
	using namespace details;
	return {
		clamp(X, lower, upper),
		clamp(Y, lower, upper),
		clamp(Z, lower, upper),
		clamp(W, lower, upper),
	};
}

//
// Matrix4x4
//

float _Matrix4x4<float>::operator()(size_t row, size_t col) const
{
	if (row >= 4 || row >= 4)
		throw std::invalid_argument("Index out of range.");
	return Elements[col][row];
}
float& _Matrix4x4<float>::operator()(size_t row, size_t col)
{
	if (row >= 4 || row >= 4)
		throw std::invalid_argument("Index out of range.");
	return Elements[col][row];
}

_Matrix4x4<float> _Matrix4x4<float>::Transpose() const
{
	return { {
		{ Elements[0][0], Elements[1][0], Elements[2][0], Elements[3][0] },
		{ Elements[0][1], Elements[1][1], Elements[2][1], Elements[3][1] },
		{ Elements[0][2], Elements[1][2], Elements[2][2], Elements[3][2] },
		{ Elements[0][3], Elements[1][3], Elements[2][3], Elements[3][3] },
	} };
}

_Matrix4x4<float> _Matrix4x4<float>::Transform(const _Matrix4x4<float>& matrix) const
{
	auto t = matrix.Transpose();
	auto argVectors = reinterpret_cast<const _Vector4<float>*>(&t.Elements);
	auto myVectors = reinterpret_cast<const _Vector4<float>*>(&Elements);

	return { {
		{
			myVectors[0].Dot(argVectors[0]),
			myVectors[0].Dot(argVectors[1]),
			myVectors[0].Dot(argVectors[2]),
			myVectors[0].Dot(argVectors[3]),
		},
		{
			myVectors[1].Dot(argVectors[0]),
			myVectors[1].Dot(argVectors[1]),
			myVectors[1].Dot(argVectors[2]),
			myVectors[1].Dot(argVectors[3]),
		},
		{
			myVectors[2].Dot(argVectors[0]),
			myVectors[2].Dot(argVectors[1]),
			myVectors[2].Dot(argVectors[2]),
			myVectors[2].Dot(argVectors[3]),
		},
		{
			myVectors[3].Dot(argVectors[0]),
			myVectors[3].Dot(argVectors[1]),
			myVectors[3].Dot(argVectors[2]),
			myVectors[3].Dot(argVectors[3]),
		},
	} };
}

_Vector4<float> _Matrix4x4<float>::Transform(const _Vector4<float>& vector) const
{
	auto myVectors = reinterpret_cast<const _Vector4<float>*>(&Elements);

	return
	{
		myVectors[0].Dot(vector),
		myVectors[1].Dot(vector),
		myVectors[2].Dot(vector),
		myVectors[3].Dot(vector),
	};
}

double _Matrix4x4<double>::operator()(size_t row, size_t col) const
{
	if (row >= 4 || row >= 4)
		throw std::invalid_argument("Index out of range.");
	return Elements[col][row];
}
double& _Matrix4x4<double>::operator()(size_t row, size_t col)
{
	if (row >= 4 || row >= 4)
		throw std::invalid_argument("Index out of range.");
	return Elements[col][row];
}

_Matrix4x4<double> _Matrix4x4<double>::Transpose() const
{
	return { {
		{ Elements[0][0], Elements[1][0], Elements[2][0], Elements[3][0] },
		{ Elements[0][1], Elements[1][1], Elements[2][1], Elements[3][1] },
		{ Elements[0][2], Elements[1][2], Elements[2][2], Elements[3][2] },
		{ Elements[0][3], Elements[1][3], Elements[2][3], Elements[3][3] },
		} };
}

_Matrix4x4<double> _Matrix4x4<double>::Transform(const _Matrix4x4<double>& matrix) const
{
	auto t = matrix.Transpose();
	auto argVectors = reinterpret_cast<const _Vector4<double>*>(&t.Elements);
	auto myVectors = reinterpret_cast<const _Vector4<double>*>(&Elements);

	return { {
		{
			myVectors[0].Dot(argVectors[0]),
			myVectors[0].Dot(argVectors[1]),
			myVectors[0].Dot(argVectors[2]),
			myVectors[0].Dot(argVectors[3]),
		},
		{
			myVectors[1].Dot(argVectors[0]),
			myVectors[1].Dot(argVectors[1]),
			myVectors[1].Dot(argVectors[2]),
			myVectors[1].Dot(argVectors[3]),
		},
		{
			myVectors[2].Dot(argVectors[0]),
			myVectors[2].Dot(argVectors[1]),
			myVectors[2].Dot(argVectors[2]),
			myVectors[2].Dot(argVectors[3]),
		},
		{
			myVectors[3].Dot(argVectors[0]),
			myVectors[3].Dot(argVectors[1]),
			myVectors[3].Dot(argVectors[2]),
			myVectors[3].Dot(argVectors[3]),
		},
		} };
}

_Vector4<double> _Matrix4x4<double>::Transform(const _Vector4<double>& vector) const
{
	auto myVectors = reinterpret_cast<const _Vector4<double>*>(&Elements);

	return
	{
		myVectors[0].Dot(vector),
		myVectors[1].Dot(vector),
		myVectors[2].Dot(vector),
		myVectors[3].Dot(vector),
	};
}

namespace MatrixTransform
{
	namespace details
	{
		// Notice the initialization lists are transposed matricies.
		using namespace std;
		inline Matrix4x4 RotateByX(Float deg)
		{
			return { {
				{ 1, 0, 0, 0 },
				{ 0, cos(deg), -sin(deg), 0 },
				{ 0, sin(deg), cos(deg), 0 },
				{ 0, 0, 0, 1 }
				} };
		}
		inline Matrix4x4 RotateByY(Float deg)
		{
			return { {
				{ cos(deg), 0, sin(deg), 0 },
				{ 0, 1, 0, 0 },
				{ -sin(deg), 0, cos(deg), 0 },
				{ 0, 0, 0, 1 }
				} };
		}
		inline Matrix4x4 RotateByZ(Float deg)
		{
			return { {
				{ cos(deg), -sin(deg), 0, 0 },
				{ sin(deg), cos(deg), 0, 0 },
				{ 0, 0, 1, 0 },
				{ 0, 0, 0, 1 }
				} };
		}
	}

	Matrix4x4 Translate(Float x, Float y, Float z)
	{
		return { {
			{ 1, 0, 0, 0 },
			{ 0, 1, 0, 0 },
			{ 0, 0, 1, 0 },
			{ x, y, z, 1 }
			} };
	}

	template<char TAxis>
	Matrix4x4 Rotate(Float deg)
	{
		static_assert(TAxis == 'x' || TAxis == 'X' ||
			TAxis == 'y' || TAxis == 'Y' ||
			TAxis == 'z' || TAxis == 'Z', "Unknown axis to rotate.");
	}
	template<> Matrix4x4 Rotate<'x'>(Float deg) { return details::RotateByX(deg); }
	template<> Matrix4x4 Rotate<'X'>(Float deg) { return details::RotateByX(deg); }
	template<> Matrix4x4 Rotate<'y'>(Float deg) { return details::RotateByY(deg); }
	template<> Matrix4x4 Rotate<'Y'>(Float deg) { return details::RotateByY(deg); }
	template<> Matrix4x4 Rotate<'z'>(Float deg) { return details::RotateByZ(deg); }
	template<> Matrix4x4 Rotate<'Z'>(Float deg) { return details::RotateByZ(deg); }

	Matrix4x4 Scale(Float x, Float y, Float z)
	{
		return { {
			{ x, 0, 0, 0 },
			{ 0, y, 0, 0 },
			{ 0, 0, z, 0 },
			{ 0, 0, 0, 1 }
		} };
	}
}

_L_NS_END
