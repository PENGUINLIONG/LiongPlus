// File: Matrix4x4.hpp
// Author: Rendong Liang (Liong)
#pragma once
#include "_"

_L_NS_BEG

//
// Vector4
//

template<typename TFloat = Float>
struct _Vector4;
template<>
struct _Vector4<float>
{
public:
	union { float X, R; };
	union { float Y, G; };
	union { float Z, B; };
	union { float W, A; };
	
	float operator()(size_t pos) const;
	float& operator()(size_t pos);

	float Dot(const _Vector4& vector) const;
	_Vector4<float> Clamp(float lower, float upper) const;
};
template<>
struct _Vector4<double>
{
public:
	union { double X, R; };
	union { double Y, G; };
	union { double Z, B; };
	union { double W, A; };

	double operator()(size_t pos) const;
	double& operator()(size_t pos);

	double Dot(const _Vector4& vector) const;
	_Vector4<double> Clamp(double lower, double upper) const;
};
using Vector4 = _Vector4<>;

//
// Matrix4x4
//

template<typename TFloat = Float> struct _Matrix4x4;
template<>
struct _Matrix4x4<float>
{
public:
	float Elements[4][4];

	float operator()(size_t row, size_t col) const;
	float& operator()(size_t row, size_t col);

	// Matrix4x4 Inverse() const;
	_Vector4<float> Transform(const _Vector4<float>& vector) const;
	_Matrix4x4<float> Transform(const _Matrix4x4<float>& matrix) const;
	_Matrix4x4<float> Transpose() const;
};
template<>
struct _Matrix4x4<double>
{
public:
	double Elements[4][4];

	double operator()(size_t row, size_t col) const;
	double& operator()(size_t row, size_t col);

	// Matrix4x4 Inverse() const;
	_Vector4<double> Transform(const _Vector4<double>& vector) const;
	_Matrix4x4<double> Transform(const _Matrix4x4<double>& matrix) const;
	_Matrix4x4<double> Transpose() const;
};
using Matrix4x4 = _Matrix4x4<>;

namespace MatrixTransform
{
	constexpr Matrix4x4 Identity()
	{
		return { {
			{ 1, 0, 0, 0 },
			{ 0, 1, 0, 0 },
			{ 0, 0, 1, 0 },
			{ 0, 0, 0, 1 }
			} };
	}

	Matrix4x4 Translate(Float x, Float y, Float z = 0);

	template<char TAxis = 'Z'>
	Matrix4x4 Rotate(Float deg);
	template<> Matrix4x4 Rotate<'x'>(Float deg);
	template<> Matrix4x4 Rotate<'X'>(Float deg);
	template<> Matrix4x4 Rotate<'y'>(Float deg);
	template<> Matrix4x4 Rotate<'Y'>(Float deg);
	template<> Matrix4x4 Rotate<'z'>(Float deg);
	template<> Matrix4x4 Rotate<'Z'>(Float deg);

	Matrix4x4 Scale(Float x, Float y, Float z = 1);
}


_L_NS_END
