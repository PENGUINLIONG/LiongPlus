// File: UIFactory.hpp
// Author: Rendong Liang (Liong)
#pragma once
#include <memory>
#include "_"

_L_NS_BEG_GRAPHICS_UI

template<typename T>
struct UIFactory;

_L_NS_END_GRAPHICS_UI
