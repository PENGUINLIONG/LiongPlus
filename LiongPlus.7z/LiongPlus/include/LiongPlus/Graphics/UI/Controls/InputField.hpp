// File: InputField.hpp
// Author: Rendong Liang (Liong)
#include "_"
#include "../Control.hpp"
#include "TextBlock.hpp"

_L_NS_BEG_GRAPHICS_UI_CONTROLS

class InputField
	: public Control
{
protected:
	TextBlock _Text();

public:
	void OnKeyDown(const IUIElement& sender, KeyboardEventArgs args);
	void OnImeInput
};

_L_NS_END_GRAPHICS_UI_CONTROLS
